﻿
namespace JabbR.ContentProviders.Core
{
    public class ContentProviderResult
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
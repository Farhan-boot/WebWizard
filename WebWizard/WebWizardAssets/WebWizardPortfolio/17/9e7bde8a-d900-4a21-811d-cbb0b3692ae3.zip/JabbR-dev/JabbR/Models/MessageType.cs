﻿namespace JabbR.Models
{
    public enum MessageType
    {
        Default,
        Notification
    }
}
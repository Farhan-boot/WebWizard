﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace JabbR.Models
{
    public enum UserStatus
    {
        Active,
        Inactive,
        Offline
    }
}
﻿namespace JabbR.Models
{
    public class ClientState
    {
        public string ActiveRoom { get; set; }
    }
}
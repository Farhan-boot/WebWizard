using System;
using System.Data.Entity.Migrations;
using System.IO;

namespace JabbR.Models.Migrations
{
    public partial class ElmahInSql : DbMigration
    {
        public override void Up()
        {
            // Nothing
        }

        public override void Down()
        {
            // No idea
        }
    }
}

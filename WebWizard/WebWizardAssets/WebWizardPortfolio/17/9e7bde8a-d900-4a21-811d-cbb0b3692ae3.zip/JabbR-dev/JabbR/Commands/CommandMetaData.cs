﻿namespace JabbR.Commands
{
    public class CommandMetaData
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Arguments { get; set; }
        public string Group { get; set; }
        public string ConfirmMessage { get; set; }
    }
}
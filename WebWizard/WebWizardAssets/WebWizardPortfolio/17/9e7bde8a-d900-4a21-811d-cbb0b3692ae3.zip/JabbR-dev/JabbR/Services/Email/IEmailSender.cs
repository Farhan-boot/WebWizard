namespace JabbR.Services
{
    public interface IEmailSender
    {
        void Send(Email email);
    }
}
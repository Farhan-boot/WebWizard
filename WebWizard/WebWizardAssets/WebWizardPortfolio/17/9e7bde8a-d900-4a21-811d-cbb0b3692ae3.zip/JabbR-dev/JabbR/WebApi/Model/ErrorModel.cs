﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace JabbR.WebApi.Model
{
    public class ErrorModel
    {
        public string Message { get; set; }
    }
}
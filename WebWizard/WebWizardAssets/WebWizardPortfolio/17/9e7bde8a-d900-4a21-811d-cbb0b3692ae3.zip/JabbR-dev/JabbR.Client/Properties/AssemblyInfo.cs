﻿using System.Reflection;

[assembly: AssemblyTitle("JabbR.Client")]
[assembly: AssemblyDescription(".NET Client for JabbR (https://github.com/davidfowl/JabbR)")]
[assembly: AssemblyCompany("David Fowler")]
[assembly: AssemblyProduct("JabbR.Client")]

[assembly: AssemblyVersion("0.1")]
[assembly: AssemblyFileVersion("1.0.0.0")]

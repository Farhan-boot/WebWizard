﻿namespace JabbR.Client.Models
{
    public enum UserStatus
    {
        Active,
        Inactive,
        Offline
    }
}
